package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Rooms extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms);

        final TextView textViewdays = findViewById(R.id.daystext);


        final android.widget.SeekBar seekBardays = findViewById(R.id.seekBardays);

        Button done = findViewById(R.id.next2btn);

        final RadioGroup roomgroup = findViewById(R.id.roomgroup);


        final RadioButton single = findViewById(R.id.Single);
        final RadioButton Double = findViewById(R.id.Double);
        final RadioButton Triple = findViewById(R.id.Triple);
        final RadioButton King = findViewById(R.id.King);


        final Bundle get = getIntent().getExtras();




        seekBardays.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int i, boolean b) {

                textViewdays.setText(i + " Days");


            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {

            }
        });


        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Rooms.this, Print.class);
                intent.putExtra("days", seekBardays.getProgress()+"");

                intent.putExtra("name", get.getString("name"));
                intent.putExtra("gender", get.getString("gender"));
                intent.putExtra("number", get.getString("number"));
                intent.putExtra("email", get.getString("email"));
                intent.putExtra("age", get.getString("age"));



                int checkedradio = roomgroup.getCheckedRadioButtonId();

                if (checkedradio == R.id.Single) {
                    intent.putExtra("room", "Single");
                }
                else if (checkedradio == R.id.Double) {
                    intent.putExtra("room", "Double");
                }
                else if (checkedradio == R.id.Triple) {
                    intent.putExtra("room", "Triple");
                }
                else  if (checkedradio == R.id.King) {
                    intent.putExtra("room", "King");
                }


                startActivity(intent);
            }
        });
    }
}