package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        final android.widget.SeekBar seekBarage =  findViewById(R.id.seekBarage);


        final TextView textViewage = findViewById(R.id.textViewage);
        final TextView name = findViewById(R.id.etname);
        final TextView number = findViewById(R.id.etnum);
        final TextView email = findViewById(R.id.etmail);


        final Button nextbtn = findViewById(R.id.nextbtn);


        final RadioGroup gendergroup = findViewById(R.id.gendergroup);


        final RadioButton single = findViewById(R.id.male);
        final RadioButton Double = findViewById(R.id.female);


        seekBarage.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int i, boolean b) {

                textViewage.setText("Your are "+i+" years");


            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {

            }
        });

        nextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (seekBarage.getProgress() >= 18) {
                    Intent intent = new Intent(info.this, Rooms.class);
                    intent.putExtra("name", name.getText().toString());
                    intent.putExtra("number", number.getText().toString());
                    intent.putExtra("email", email.getText().toString());
                    intent.putExtra("age", seekBarage.getProgress() + "");


                    int gendercheck = gendergroup.getCheckedRadioButtonId();


                    if (gendercheck == R.id.male) {
                        intent.putExtra("gender", "Male");
                    } else if (gendercheck == R.id.female) {
                        intent.putExtra("gender", "Female");
                    }


                    startActivity(intent);
                }
                else{
                    openDialog2();
                }
            }
        });
    }
    public void openDialog2(){
        DialogBox2 koo = new DialogBox2();
        koo.show(getSupportFragmentManager(), "Abdullah");
    }
}