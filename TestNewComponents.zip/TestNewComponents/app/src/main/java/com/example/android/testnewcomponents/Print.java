package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Print extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print);

        Button done = findViewById(R.id.right);
        Button Redo = findViewById(R.id.Redo);


        TextView name = findViewById(R.id.name);
        TextView gender = findViewById(R.id.gender);
        TextView age = findViewById(R.id.age);
        TextView email = findViewById(R.id.email);
        TextView phone = findViewById(R.id.phone);
        TextView roomt = findViewById(R.id.roomt);
        TextView numdays = findViewById(R.id.numdays);


        Bundle get =getIntent().getExtras();

        name.setText("Your name is: "+get.getString("name"));
        gender.setText("Your gender is: "+get.getString("gender"));
        age.setText("You're "+get.getString("age") + " Years old");
        email.setText("Your email is: "+get.getString("email"));
        phone.setText("Your number is: "+get.getString("number"));
        roomt.setText("Your room choice is: "+get.getString("room"));
        numdays.setText("You're staying for: "+get.getString("days")+" days");


        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog3();
            }
        });


        Redo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Print.this , info.class);
                startActivity(intent);
            }
        });
    }
    public void openDialog3(){
        DialogBox3 koo = new DialogBox3();
        koo.show(getSupportFragmentManager(), "Abdullah");
    }
}